Readme for CB64 Win32 Port 2nd Beta
===================================

This file contains basic information for CB64 Win32. Please read
all sections before you start. It will answer some basic
questions and contains a FAQ as well.

1. Contents
-----------

	1. Contents
	2. Basic Overview
	3. Getting started
	4. FAQ
	5. Error Messages
	6. Contact

2. Basic Overview
-----------------

CB64 is a software emulator for the C64 Computer. The newest
version of CB64 is available at http://www.comeback.c64.org. If you
don't know whether you are using the newest version please check there.
Although we try our utmost it is quite a fact that it is impossible to
code an emulator which is 100%ly compatible with the original. If one
of your programs does not run correctly its maybe because of this. CB64
is only a C64 emulator and not a C64 Peripherals emulator. It does NOT
emulate the 1541 so far, but anyway we are thinking of that and 
additonal hardware support. It is NOT implemented yet. If you have a
.d64 or .t64 image file please check at the homepage too and have a
look at the FAQ there to see how you can make use of those images.

3. Getting Started
------------------

Just unzip the distribution which you might have done when reading this
and doubleclick the file cb64w.exe ... here you go. To start a program is
quite easy. If it is in the same directory as CB64 then you can load it
with the standard load command of the C64. If it is not in the directory
just use the menu to open it (Goto File/Load Program..). To load a
cartridge dump use the menu as well. (Goto File/Load Cartridge). Standard
windows help is not implemented yet, but will be in the next release.
To Reset the emulator look at the menu (Goto Emulation/Reset). Using
CB64 is quite easy. You will be able to handle it after 5 minutes.

4. FAQ
------

Q: Is it legal to get copyrighted games for the C64 for free on the net?
A: Good question.  It is true that most of the games on the net are still 
   copyrighted, and will be for a long while.  However, the companies 
   and authors that hold these copyrights have not taken any action 
   against anyone offering games via ftp or www.      
   So, it seems that most copyright holders of old C64 games do not
   especially care about what happens to those games which are not
   selling anymore.  As a result, it's mostly up to your sense
   of morality to decide whether to support these sites.  

Q: Is any program provided with CB64?
A: Yes, there are a few files provided with it. Just look at the directory
   of CB64.

Q: Where do I get the latest version of CB64 for various platforms?
A: Point your Webbrowser to: http//www.comeback.c64.org

Q: I want to participate in the Win32 Port. How?
A: Look at the end of this readme in the contact section. If you want to
   take part please provide information about your skills.

Q: I want to distribute CB64 Windows Port. May I?
A: Yes and no. As long as you do it just for fun and not for any commercial
   purposes you are allowed. If there is a commercial background of any kind
   ask before you do. CB64 Windows Port is free. You are not allowed to sell
   it without permission!!

Q: How .....???
A: Look at http://www.comeback.c64.org


5. Error Messages
-----------------
If you receive an error message by Windows it's tough luck. If you receive one
by the C64 look below to know what it means :-)

BAD DATA              String data was received from an open file, but the
                      program was expecting numeric data.
BAD SUBSCRIPT         The program was trying to reference an  element  of
                      an array whose  number  is  outside  of  the  range
                      specified in the DIM statement.
BREAK                 Program execution was stopped because you  hit  the
                      <STOP> key.
CAN'T CONTINUE        The CONT command will not work,  either because the
                      program was never RUN,  there has been an error, or
                      a line has been edited.
DEVICE NOT PRESENT    The required I/O device was not  available  for  an
                      OPEN, CLOSE, CMD, PRINT#, INPUT#, or GET#.
DIVISION BY ZERO      Division by zero is a mathematical oddity  and  not
                      allowed.
EXTRA IGNORED         Too many items of data were typed in response to an
                      INPUT statement. Only the first few items were
                      accepted.
FILE NOT FOUND        If you were looking for a file on tape, and END-OF-
                      TAPE marker was found. If you were looking on disk,
                      no file with that name exists.
FILE NOT OPEN         The file specified in a CLOSE, CMD, PRINT#, INPUT#,
                      or GET#, must first be OPENed.
FILE OPEN             An attempt was made to open a file using the number
                      of an already open file.
FORMULA TOO COMPLEX   The string expression  being  evaluated  should  be
                      split into at least two parts  for  the  system  to
                      work with, or a formula has too many parentheses.
ILLEGAL DIRECT        The  INPUT  statement  can  only  be  used within a
                      program, and not in direct mode.
ILLEGAL QUANTITY      A number used as the  argument  of  a  function  or
                      statement is out of the allowable range.
LOAD                  There is a problem with the program on tape.
NEXT WITHOUT FOR      This is caused by either incorrectly nesting  loops
                      or having a variable name in a NEXT statement  that
                      doesn't correspond with one in a FOR statement.
NOT INPUT FILE        An  attempt  was  made  to INPUT or GET data from a
                      file which was specified to be for output only.
NOT OUTPUT FILE       An attempt was mode to PRINT data to a  file  which
                      was specified as input only.
OUT OF DATA           A READ statement was executed but there is no  data
                      left unREAD in a DATA statement.
OUT OF MEMORY         There is no  more  RAM  available  for  program  or
                      variables.  This  may  also occur when too many FOR
                      loops have been nested,  or when there are too many
                      GOSUBs in effect.
OVERFLOW              The result of a  computation  is  larger  than  the
                      largest number allowed, which is 1.70141884E+38.
REDIM'D ARRAY         An array may only be DIMensioned once.  If an array
                      variable  is  used  before  that array is DIM'd, an
                      automatic DIM operation is performed on that  array
                      setting the number of  elements  to  ten,  and  any
                      subsequent DIMs will cause this error.
REDO FROM START       Character   data  was  typed  in  during  an  INPUT
                      statement when numeric data was expected.  Just re-
                      type  the  entry  so  that  it is correct,  and the
                      program will continue by itself.
RETURN WITHOUT GOSUB  A RETURN statement was encountered,  and  no  GOSUB
                      command has been issued.
STRING TOO LONG       A string can contain up to 255 characters.
SYNTAX ERROR          A statement is unrecognizable by the Commodore 64.
                      A   missing   or   extra   parenthesis,  misspelled
                      keywords, etc.
TYPE MISMATCH         This error occurs when a number is used in place of
                      a string, or vice-versa.
UNDEF'D FUNCTION      A user defined function was referenced,  but it has
                      never been defined using the DEF FN statement.
UNDEF'D STATEMENT     An attempt was made to GOTO or GOSUB or RUN  a line
                      number that doesn't exist.
VERIFY                The program on tape or  disk  does  not  match  the
                      program currently in memory.


6. Contact
----------

If you want to help us or to report any errors:
dluxen@hotmail.com

A note to spam mailers: I dont want a hot business opportunity :)